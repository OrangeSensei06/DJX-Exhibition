#!/usr/bin/env python3
"""Rebuild the Biryani geometry encoded in mughal-times.html as editable GLB layers.

All radii, primitive shapes, colors, roughness/metalness, counts, dome
placement, and layer naming come from the Three.js procedural code.
The HTML uses Math.random() without a seed; this script creates a stable
reproducible instance rather than claiming the original frame's exact random
particle coordinates. Procedural sprites, shader effects, and interactions
are not mesh geometry and are not exported into the GLB.

Requires numpy, scipy and trimesh.
"""
from pathlib import Path
import argparse
import numpy as np
import trimesh
from scipy.spatial.transform import Rotation
from trimesh.visual.material import PBRMaterial

SEED = 20261102

# Exploded view offsets, copied from the page's "off" array.
EXPLODE_Y = {'bowl':0.0, 'rice':0.9, 'saffron':1.5,
             'protein':2.1, 'onions':2.7, 'herbs':3.3, 'spices':3.9}


def rgb(n):
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255, 1.0]


def material(name, color, rough=0.6, metallic=0, emissive=None, double_sided=False):
    kwargs = dict(name=name, baseColorFactor=rgb(color), roughnessFactor=rough,
                  metallicFactor=metallic, doubleSided=double_sided)
    if emissive is not None:
        kwargs['emissiveFactor'] = rgb(emissive)[:3]
    return PBRMaterial(**kwargs)


def styled_mesh(mesh, mat):
    mesh.visual = trimesh.visual.TextureVisuals(material=mat)
    return mesh


def lathe(profile, sections=64):
    """Revolve (radius, y) profile around the Y axis, like THREE.LatheGeometry."""
    theta = np.linspace(0, np.pi * 2, sections+1)
    vertices = np.array([[rad*np.cos(t), y, rad*np.sin(t)]
                         for t in theta for rad,y in profile], dtype=np.float64)
    p = len(profile)
    faces = []
    for s in range(sections):
        for j in range(p-1):
            a = s*p+j; b = (s+1)*p+j
            faces.extend([[a,a+1,b],[b,a+1,b+1]])
    out = trimesh.Trimesh(vertices=vertices, faces=np.asarray(faces), process=False)
    out.update_faces(out.nondegenerate_faces())
    # Double sided is enabled for original bowl material. Normals are not
    # critical for the profile's thin back-facing portions.
    return out


def torus():
    # Source THREE.TorusGeometry(1.48, 0.035, 12, 64), rotated to be horizontal.
    out = trimesh.creation.torus(major_radius=1.48, minor_radius=0.035,
                                 major_sections=64, minor_sections=12)
    out.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2, [1,0,0]))
    out.apply_translation([0,1.12,0])
    return out


def create_base(kind, dimensions=None):
    if kind == 'cylinder':
        out = trimesh.creation.cylinder(radius=0.02, height=0.22, sections=5)
        out.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2, [1,0,0]))
        return out
    if kind == 'box':
        return trimesh.creation.box(extents=dimensions)
    if kind == 'icosahedron':
        return trimesh.creation.icosphere(subdivisions=0, radius=dimensions)
    if kind == 'octahedron':
        return trimesh.convex.convex_hull(np.array([[dimensions,0,0],[-dimensions,0,0],
          [0,dimensions,0],[0,-dimensions,0],[0,0,dimensions],[0,0,-dimensions]]))
    if kind == 'sphere':
        base = trimesh.creation.uv_sphere(radius=dimensions[0], count=[8,6])
        base.apply_scale(np.array(dimensions[1:]))
        return base
    raise ValueError(kind)


def instanced_geometry(base, count, radius, lift, scale, rng):
    """Bake Three.js InstancedMesh transforms for widest GLB compatibility."""
    # The original code draws random radius uniformly by area on a dome,
    # then independently draws rotation in [0,3] radians and size in [.8,1.2].
    r = radius * np.sqrt(rng.random(count))
    a = rng.uniform(0, 2*np.pi, count)
    xyz = np.column_stack((np.cos(a)*r, .68 + .6*(1-(r/1.25)**2) + lift, np.sin(a)*r))
    xyz_rot = rng.uniform(0, 3, (count,3))
    mats = Rotation.from_euler('XYZ', xyz_rot).as_matrix()
    sizes = scale*rng.uniform(.8,1.2,count)
    verts = np.asarray(base.vertices, dtype=np.float32)
    faces = np.asarray(base.faces, dtype=np.int32)
    expanded = np.einsum('nij,vj->nvi', mats, verts) * sizes[:,None,None] + xyz[:,None,:]
    f = faces[None,:,:] + np.arange(count, dtype=np.int32)[:,None,None] * len(verts)
    return trimesh.Trimesh(vertices=expanded.reshape(-1,3), faces=f.reshape(-1,3), process=False)


def build(dest):
    rng = np.random.default_rng(SEED)
    s = trimesh.Scene()
    I = np.eye(4)
    s.graph.update(frame_to='Biryani', frame_from=s.graph.base_frame, matrix=I)
    for name in EXPLODE_Y:
        s.graph.update(frame_to=name, frame_from='Biryani', matrix=I)

    def add(layer, name, mesh, mat):
        styled_mesh(mesh,mat)
        s.add_geometry(mesh, geom_name=name, node_name=name, parent_node_name=layer)
        print(f'  {layer:8}  {name:25}  {len(mesh.vertices):>8,} verts  {len(mesh.faces):>8,} tris')

    # Profile from `const pr = ...` in uploaded HTML, used in THREE.LatheGeometry.
    profile = [(0,0),(.45,0),(.8,.08),(1.2,.45),(1.42,.9),(1.52,1.12),
               (1.44,1.14),(1.34,.95),(1.1,.55),(.7,.28),(0,.24)]
    add('bowl','Copper_Bowl',lathe(profile),material('Copper_Metal',0xc77b3a,.32,.85,double_sided=True))
    add('bowl','Gold_Rim',torus(),material('Golden_Rim',0xf0c36a,.25,1))

    grain = create_base('cylinder')
    add('rice','Basmati_Rice_1500',instanced_geometry(grain,1500,1.2,0,1,rng),material('Basmati_Rice_Ivory',0xf4ecd6,.5))
    add('saffron','Saffron_Rice_520',instanced_geometry(grain,520,1.15,.05,1.05,rng),material('Saffron_Rice_Gold',0xf0a21e,.5,emissive=0x552200))

    add('protein','Meat_Pieces_11',instanced_geometry(create_base('icosahedron',.17),11,1,.1,1,rng),material('Marinated_Meat_Brown',0x8a3f1c,.8))
    add('protein','Vegetable_Pieces_6',instanced_geometry(create_base('box',[.2,.2,.2]),6,1,.12,1,rng),material('Marinated_Pieces_Orange',0xd9702a,.7))
    add('onions','Fried_Onion_Pieces_90',instanced_geometry(create_base('box',[.24,.02,.05]),90,1.15,.12,1,rng),material('Birista_Fried_Onions',0x9a5a1c,.8))

    # THREE.SphereGeometry(.12,8,6) scaled in its geometry (1,.12,.6).
    add('herbs','Mint_Coriander_55',instanced_geometry(create_base('sphere',[.12,1,.12,.6]),55,1.15,.15,1.4,rng),material('Mint_Coriander_Green',0x2f8a3a,.7))

    add('spices','Whole_Spices_16',instanced_geometry(create_base('octahedron',.07),16,1.05,.15,1,rng),material('Whole_Spices_Brown',0x3a2010))
    add('spices','Cashews_16',instanced_geometry(create_base('sphere',[.09,1.3,.8,.8]),16,1.05,.16,1,rng),material('Cashews_Ivory',0xe8cf98))

    s.metadata['name']='Mughal Times — Biryani'
    s.metadata['source']='mughal-times.html, procedural Three.js model'
    s.metadata['seed']=SEED
    s.metadata['original_explode_y_offsets']=EXPLODE_Y
    data = trimesh.exchange.gltf.export_glb(s, include_normals=True)
    Path(dest).write_bytes(data)
    print(f'Wrote: {dest} ({len(data):,} bytes)')
    return s


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('-o','--output',default=str(Path(__file__).parent/'Mughal_Times_Biryani.glb'))
    args=ap.parse_args()
    build(args.output)
